#ifndef CABECALHO_H
#define CABECALHO_H
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Pagamento
{
public:
    double valorDoPagamento;
    string nomeDoFuncionario;
    double getValor();
    string getNome();
    void setValor(double valor);
    void setNome(string nome);
};

class ControleDePagamentos
{
public:
    vector <Pagamento> pagamentos;
    void setPagamento(Pagamento p);
    double calculaTotalDePagamentos();
    int existePagamentoParaFuncionario (string nomeFuncionario);
};

double Pagamento::getValor()
{
    return valorDoPagamento;
}
string Pagamento::getNome()
{
    return nomeDoFuncionario;
}
void Pagamento::setValor(double valor)
{
    valorDoPagamento = valor;
}
void Pagamento::setNome(string nome)
{
    nomeDoFuncionario = nome;
}
void ControleDePagamentos::setPagamento(Pagamento p)
{
    pagamentos.push_back(p);
}
double ControleDePagamentos::calculaTotalDePagamentos()
{
    unsigned int i;
    double valortotal = 0;
    for(i = 0; i < pagamentos.size(); i++)
    {
        valortotal += pagamentos[i].valorDoPagamento;
    }
    return valortotal;
}

#endif // CABECALHO_H
