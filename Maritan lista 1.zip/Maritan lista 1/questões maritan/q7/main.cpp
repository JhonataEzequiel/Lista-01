#include <string>
#include <iostream>
#include <vector>
#include "cabecalho.h"
using namespace std;

int main()
{
    Pagamento p1 ,p2;
    ControleDePagamentos p;
    string s1 = "Maria", s2 = "Jose";

    p1.setNome(s1);
    p1.setValor(1000);

    p2.setNome(s2);
    p2.setValor(1200);

    p.setPagamento(p1);
    p.setPagamento(p2);

    cout << "Total: " <<p.calculaTotalDePagamentos() << endl;

    return 0;
}
