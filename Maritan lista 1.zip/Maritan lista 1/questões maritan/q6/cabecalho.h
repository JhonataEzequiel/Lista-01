#ifndef CABECALHO_H
#define CABECALHO_H
#include <iostream>
#include <string>
using namespace std;
class Data
{
public:
    int dia, mes, ano;
};
class Horario
{
public:
    int hora, minu, seg;
};
class voo
{
    Data data;
    Horario horario;
    int vagas[100]; int numero;
public:
    voo(Data d, Horario h, int numero);
    int proximolivre(int cadeira);
    string verifica(int cadeira);
    bool ocupa(int cadeira);
    int Vagas();
    int getNumVoo();
    Data getData();
    Horario getHorario();
};

voo::voo(Data d, Horario h, int numero)
{
    this -> numero = numero;
    data = d;
    horario = h;
    for(int i = 0; i<100; i++)
        vagas[i] = 0;
}

int voo::proximolivre(int cadeira)
{
    int i;
    for(i = cadeira; i<100; i++)
    {
        if(vagas[i] == 0){
            cadeira = i;
            break;
        }
    }
    return cadeira;
}

string voo::verifica(int cadeira)
{
    if(vagas[cadeira] == 1)
        return "Cadeira ja ocupada";
    else
        return "Cadeira livre";
}

bool voo::ocupa(int cadeira)
{
    int i;

    if(vagas[cadeira] == 0)
        i = 1;
    else
        i = 0;

    vagas[cadeira] = 1;

    if(i)
        return true;
    else
        return false;
}

int voo::Vagas()
{
    int qvagas = 0;
    for(int i = 0; i<100; i++)
    {
        if(vagas[i] == 0)
            qvagas+=1;
    }
    return qvagas;
}

int voo::getNumVoo()
{
    return numero;
}
Data voo::getData()
{
    return data;
}
Horario voo::getHorario()
{
    return horario;
}

#endif // CABECALHO_H
