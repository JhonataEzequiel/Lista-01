#include <iostream>
#include "cabecalho.h"
#include <string>
using namespace std;

int main()
{
    Data d;
    d.dia = 1; d.mes = 7; d.ano = 2009;

    Horario h;
    h.hora = 5; h.minu = 54; h.seg = 33;

    voo v(d, h, 10);

    int cadeira = 10;

    if(v.ocupa(cadeira))
        cout << "Cadeira Ocupada" << endl;

    cout << v.verifica(cadeira) << endl;

    cout << "A proxima cadeira livre eh a numero: " << v.proximolivre(cadeira) << endl;

    cout << "Quantidade de cadeiras vagas: " << v.Vagas() << endl;

    return 0;
}
