#include <iostream>
#include "cabacalho.h"
#include <string>
#include <stdlib.h>
#include <windows.h>

using namespace std;

int main()
{
    system("Color F0");
    Invoice i1;
    int numero, quantidade, x;
    double preco;
    string descricao;

    cout << "Digite o numero do produto:" << endl;
    cin >> numero;
    cout << "Digite a quantidade do protudo:" << endl;
    cin >> quantidade;
    cout << "Digite o preco do produto:" << endl;
    cin >> preco;
    cout << "Digite a descricao do produto:" << endl;
    getline(cin, descricao);
    getline(cin, descricao);

    cout << "Deseja testar o construtor com valores padroes?(Digite 1, se n�o, digite qualquer numero)" << endl;
    cin >> x;

    if(x == 1){
    //Teste do Construtor
    cout << "Numero: " <<i1.getNum() << endl;
    cout << "Preco: " <<i1.getPreco() << endl;
    cout << "Descricao: " << i1.getDescricao() << endl;
    cout << "Quantidade: " << i1.getQuantidade() << endl;
    }

    i1.setDescricao(descricao);
    i1.setNum(numero);

    cout << "Valor da fatura: " << i1.getInvoiceAmount(quantidade, preco) << endl;
    system("pause");
    return 0;
}
