#ifndef INVOICE_H
#define INVOICE_H
#include <iostream>
#include <string>

using namespace std;

class Invoice
{
private:
    int num;
    string descricao;
    int quantidade;
    double preco;
public:
    Invoice();
    void setDescricao(string descricao);
    void setNum(int num);
    int getNum();
    int getQuantidade();
    string getDescricao();
    double getPreco();
    double getInvoiceAmount(int quantidade, double preco);
};
Invoice::Invoice()
{
    this -> num = 0;
    this -> descricao = "Descricao vazia";
    this -> quantidade = 0;
    this -> preco = 0.0;
}
void Invoice::setDescricao(string descricao)
{
    this -> descricao = descricao;
}
void Invoice::setNum(int num)
{
    this -> num = num;
}
int Invoice::getNum()
{
    return num;
}
int Invoice::getQuantidade()
{
    return quantidade;
}
string Invoice::getDescricao()
{
    return descricao;
}
double Invoice::getPreco()
{
    return preco;
}
double Invoice::getInvoiceAmount(int quantidade, double preco)
{
    double fatura;
    if(quantidade<0)
    {
        quantidade = 0;
    }
    if(preco<0)
    {
        preco = 0.0;
    }

    fatura = quantidade * preco;
    return fatura;
}

#endif // INVOICE_H
