#include <iostream>
#include "cabecalho.h"
using namespace std;

int main()
{
    Data d1, d2;
    cout << "sao iguais (?):" << d1.compara(d2) << "\n" << endl;
	//****
    Data d3(10, 9, -2000);
    
    cout << d3.getDia() << '/' << d3.getMes() << '/' << d3.getAno() << endl;


    return 0;
}
