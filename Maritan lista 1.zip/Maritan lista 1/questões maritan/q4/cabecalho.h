#ifndef CABECALHO_H
#define CABECALHO_H
using namespace std;

class Data
{
private:
    int dia, mes, ano;
public:
    int getDia();
    int getMes();
    int getAno();
    void setDia(int dia);
    void setMes(int mes);
    void setAno(int ano);
    Data();
    Data(int d, int m, int a);
    int compara(Data data);
    string getMesExtenso();
    bool isBisexto();
};
Data::Data()
{
    dia = 0;
    mes = 0;
    ano = 0;
}
int Data::getDia()
{
    return dia;
}
int Data::getMes()
{
    return mes;
}
int Data::getAno()
{
    return ano;
}
void Data::setDia(int dia)
{
    this -> dia = dia;
}
void Data::setMes(int mes)
{
    this -> mes = mes;
}
void Data::setAno(int ano)
{
    this -> ano = ano;
}
Data::Data(int d, int m, int a)
{
    if(a < 1 || d < 1 || m < 1)
    {
    	a = 1; d = 1; m = 1;
	}
    setDia(d); setMes(m); setAno(a);
}
int Data::compara(Data data)
{
    if(data.ano == ano && data.dia == dia && data.mes == mes)
        return 0;
    else if(data.getAno() > ano)
        return -1;
    else if(data.getMes() > mes)
        return -1;
    else if(data.getDia() > dia)
        return -1;
    else{
        return 1;
    }
}
string Data::getMesExtenso()
{
    if(mes == 1)
        return "janeiro";
    if(mes == 2)
        return "fevereiro";
    if(mes == 3)
        return "marco";
    if(mes == 4)
        return "abril";
    if(mes == 5)
        return "maio";
    if(mes == 6)
        return "junho";
    if(mes == 7)
        return "julho";
    if(mes == 8)
        return "agosto";
    if(mes == 9)
        return "setembro";
    if(mes == 10)
        return "outubro";
    if(mes == 11)
        return "novembro";
    if(mes == 12)
        return "dezembro";
}
bool Data::isBisexto()
{
    if(ano%4 == 0 && ano%10 != 0)
        return true;
    else{
        return false;
    }
}

#endif // CABECALHO_H
