#include <iostream>
#include "cabecalho.h"
using namespace std;

int main()
{
    Pessoa p1("mateus"), p2("Jose", "987317228", 22);

    cout << "Testando p1: \n" << "Nome: " << p1.getNome() << "\n" << "Telefone: " << p1.getTelefone() << "\n" << "Idade: " << p1.getIdade() << endl;
    cout << "Testando p2: \n" << "Nome: " << p2.getNome() << "\n" << "Telefone: " << p2.getTelefone() << "\n" << "Idade: " << p2.getIdade() << endl;

    return 0;
}
