#ifndef CABECALHO_H
#define CABECALHO_H
#include <iostream>
#include <string>
#include <sstream>
using namespace std;
class Horario
{
	int hora, minuto, segundo;
	public:
		Horario();
		Horario(int h, int m, int s);
		void setHorario(int hora, int minuto, int segundo);
		void setHora(int hora);
		void setMinuto(int minuto);
		void setSegundo(int segundo);
		int getHora();
		int getMinuto();
		int getSegundo();
		string avancarhorario();
};

Horario::Horario(){hora = 0; minuto = 0; segundo = 0;}
Horario::Horario(int h, int m, int s){
	if(h < 0)
		h = 0;
	if(m < 0)
		m = 0;
	if(s < 0)
		s = 0;
	if(s >= 60)
	{
		m += 1;
		s = 0;
	}
	if(m > 60)
	{
		h += 1;
		m = 0;
	}
	hora = h; minuto = m; segundo = s;
}
void Horario::setHorario(int hora, int minuto, int segundo){this -> hora = hora; this -> minuto = minuto; this -> segundo = segundo;}
void Horario::setHora(int hora){this -> hora = hora;}
void Horario::setMinuto(int minuto){this -> minuto = minuto;}
void Horario::setSegundo(int segundo){this -> segundo = segundo;}
int Horario::getHora(){return hora;}
int Horario::getMinuto(){return minuto;}
int Horario::getSegundo(){return segundo;}
string Horario::avancarhorario()
{
	stringstream ss0, ss1, ss2;
	string s0, s1, s2;
	if(segundo >= 60)
	{
		minuto += 1;
		segundo = 0;
	}
	if(minuto >= 60)
	{
		hora += 1;
		minuto = 0;
	}
	ss0 << hora;
	ss0 >> s0;
	ss1 << minuto;
	ss1 >> s1;
	ss2 << segundo;
	ss2 >> s2;
	
	return s0 + ':' + s1 + ':' + s2;
}

#endif
