#include <iostream>
#include <string>
#include "cabecalho.h"
using namespace std;

int main() {
	Horario h(10, 20, 60);
	cout << h.getHora() << ':' << h.getMinuto() << ':' << h.getSegundo();
	//k 
	return 0;
}
